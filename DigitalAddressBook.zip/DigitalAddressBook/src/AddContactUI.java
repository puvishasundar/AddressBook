import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddContactUI extends JFrame {

    JTextField nameField, phoneField, emailField, addressField, categoryField;

    public AddContactUI() {
        setTitle("Add Contact");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Background
        JPanel mainPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(255, 182, 193),
                        getWidth(), getHeight(), new Color(255, 105, 180)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setLayout(new GridBagLayout());

        // Card
        JPanel card = new JPanel();
        card.setPreferredSize(new Dimension(400, 400));
        card.setLayout(new GridLayout(7, 2, 10, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(212, 175, 55), 3));

        // Fields
        nameField = new JTextField();
        phoneField = new JTextField();
        emailField = new JTextField();
        addressField = new JTextField();
        categoryField = new JTextField();

        card.add(new JLabel("Name:"));
        card.add(nameField);

        card.add(new JLabel("Phone:"));
        card.add(phoneField);

        card.add(new JLabel("Email:"));
        card.add(emailField);

        card.add(new JLabel("Address:"));
        card.add(addressField);

        card.add(new JLabel("Category:"));
        card.add(categoryField);

        // Button
        JButton saveBtn = new JButton("Save");
        saveBtn.setBackground(new Color(212, 175, 55));
        saveBtn.setForeground(Color.BLACK);

        card.add(new JLabel(""));
        card.add(saveBtn);

        mainPanel.add(card);
        add(mainPanel);

        // Save action
        saveBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveContact();
            }
        });

        setVisible(true);
    }

    private void saveContact() {
        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO contacts(name, phone, email, address, category) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, nameField.getText());
            ps.setString(2, phoneField.getText());
            ps.setString(3, emailField.getText());
            ps.setString(4, addressField.getText());
            ps.setString(5, categoryField.getText());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Contact Saved");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }
}