import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewContactsUI extends JFrame {

    JTable table;
    DefaultTableModel model;
    JTextField searchField;

    public ViewContactsUI() {

        setTitle("View Contacts");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // MAIN PANEL
        JPanel panel = new JPanel(new BorderLayout());

        // TITLE
        JLabel title = new JLabel("All Contacts", JLabel.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 35));
        title.setForeground(new Color(212, 175, 55));

        panel.add(title, BorderLayout.NORTH);

        // TOP PANEL
        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.WHITE);

        searchField = new JTextField(20);

        JButton searchBtn = new JButton("Search");
        JButton refreshBtn = new JButton("Refresh");
        JButton deleteBtn = new JButton("Delete");
        JButton editBtn = new JButton("Edit");

        topPanel.add(new JLabel("Search: "));
        topPanel.add(searchField);
        topPanel.add(searchBtn);
        topPanel.add(refreshBtn);
        topPanel.add(editBtn);
        topPanel.add(deleteBtn);

        panel.add(topPanel, BorderLayout.SOUTH);

        // TABLE
        model = new DefaultTableModel();
        table = new JTable(model);

        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Phone");
        model.addColumn("Email");
        model.addColumn("Address");
        model.addColumn("Category");

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        add(panel);

        loadContacts();

        // SEARCH
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                searchContacts();
            }
        });

        // REFRESH
        refreshBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                loadContacts();
            }
        });

        // DELETE
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                deleteContact();
            }
        });

        // EDIT
        editBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                editContact();
            }
        });

        setVisible(true);
    }

    private void loadContacts() {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM contacts");

            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("address"),
                        rs.getString("category")
                });
            }

            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void searchContacts() {
        String keyword = searchField.getText();

        try {
            Connection conn = DBConnection.getConnection();

            String query = "SELECT * FROM contacts WHERE name LIKE ? OR phone LIKE ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();

            model.setRowCount(0);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("address"),
                        rs.getString("category")
                });
            }

            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void deleteContact() {
        int row = table.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a contact first");
            return;
        }

        int id = (int) model.getValueAt(row, 0);

        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement("DELETE FROM contacts WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();

            conn.close();

            JOptionPane.showMessageDialog(this, "Deleted!");
            loadContacts();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void editContact() {
        int row = table.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a contact first");
            return;
        }

        int id = (int) model.getValueAt(row, 0);

        String name = JOptionPane.showInputDialog("Name:", model.getValueAt(row, 1));
        String phone = JOptionPane.showInputDialog("Phone:", model.getValueAt(row, 2));
        String email = JOptionPane.showInputDialog("Email:", model.getValueAt(row, 3));
        String address = JOptionPane.showInputDialog("Address:", model.getValueAt(row, 4));
        String category = JOptionPane.showInputDialog("Category:", model.getValueAt(row, 5));

        if (name == null || name.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name required");
            return;
        }

        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement(
                    "UPDATE contacts SET name=?, phone=?, email=?, address=?, category=? WHERE id=?"
            );

            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setString(3, email);
            ps.setString(4, address);
            ps.setString(5, category);
            ps.setInt(6, id);

            ps.executeUpdate();

            conn.close();

            JOptionPane.showMessageDialog(this, "Updated!");
            loadContacts();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
}