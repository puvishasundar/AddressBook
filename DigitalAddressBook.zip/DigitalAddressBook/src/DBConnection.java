import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/address_book";
            String user = "root";
            String password = "";

            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("Connected Successfully");
            return con;

        } catch (Exception e) {
            System.out.println("Connection Failed");
            System.out.println(e);
            return null;
        }
    }
}