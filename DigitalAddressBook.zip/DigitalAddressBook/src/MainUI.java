import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainUI extends JFrame {

    public MainUI() {
        setTitle("Digital Address Book");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Gradient Background Panel
        JPanel mainPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(255, 182, 193),
                        getWidth(), getHeight(), new Color(255, 105, 180)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        mainPanel.setLayout(new GridBagLayout());

        // Card Panel (Modern Look)
        JPanel card = new JPanel();
        card.setPreferredSize(new Dimension(420, 400));
        card.setBackground(new Color(255, 255, 255, 230));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(212, 175, 55), 3),
                BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));

        // Title
        JLabel title = new JLabel("Digital Address Book");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Serif", Font.BOLD, 30));
        title.setForeground(new Color(212, 175, 55));

        card.add(title);
        card.add(Box.createRigidArea(new Dimension(0, 30)));

        // Buttons
        card.add(createButton("Add Contact"));
        card.add(Box.createRigidArea(new Dimension(0, 15)));

        card.add(createButton("View Contacts"));
        card.add(Box.createRigidArea(new Dimension(0, 15)));

        card.add(createButton("Search"));
        card.add(Box.createRigidArea(new Dimension(0, 15)));

        card.add(createButton("Delete"));

        mainPanel.add(card);
        add(mainPanel);

        setVisible(true);
    }

    // Premium Styled Button
    private JButton createButton(final String text) {
        JButton btn = new JButton(text);
        btn.setMaximumSize(new Dimension(250, 45));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);

        btn.setBackground(new Color(212, 175, 55));
        btn.setForeground(Color.BLACK);
        btn.setFont(new Font("Arial", Font.BOLD, 16));
        btn.setFocusPainted(false);

        btn.setBorder(BorderFactory.createLineBorder(new Color(255, 182, 193), 2));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover Effect
        btn.addMouseListener(new MouseAdapter() {
    public void mouseEntered(MouseEvent e) {
        JButton button = (JButton) e.getSource();
        button.setBackground(new Color(255, 215, 0));
    }

    public void mouseExited(MouseEvent e) {
        JButton button = (JButton) e.getSource();
        button.setBackground(new Color(212, 175, 55));
    }
});

        // Actions
        btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (text.equals("Add Contact")) {
                    new AddContactUI();
                } 
                else if (text.equals("View Contacts")) {
                    new ViewContactsUI();
                } 
                else if (text.equals("Search")) {
                    new ViewContactsUI(); // reuse search inside table
                } 
                else if (text.equals("Delete")) {
                    new ViewContactsUI(); // delete inside table
                }
            }
        });

        return btn;
    }

    public static void main(String[] args) {
        new MainUI();
    }
}